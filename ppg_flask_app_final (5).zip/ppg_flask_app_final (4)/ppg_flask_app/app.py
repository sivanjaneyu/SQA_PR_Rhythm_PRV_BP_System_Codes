from flask import Flask, render_template, request
import os
import pandas as pd
import numpy as np

# Use non-GUI backend to avoid Tkinter thread error
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.signal import cheby1, filtfilt
from functions import *
from scipy.signal.windows import gaussian

# Initialize Flask app
app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
STATIC_FOLDER = "static"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(STATIC_FOLDER, exist_ok=True)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        file = request.files["csvfile"]
        if file and file.filename.endswith(".csv"):
            path = os.path.join(UPLOAD_FOLDER, file.filename)
            file.save(path)

            # Load CSV and process only the first row
            data = pd.read_csv(path, header=None).values
            xcn = data[0].reshape(1, -1)
            df = pd.DataFrame(xcn)
            xf = data[0, 1:626]  # MATLAB 2:625 → Python 1:626
            Fs = 125
            Ts = 1 / Fs
            T = np.arange(0, len(xf) * Ts, Ts)
            duration = round(len(xf) * Ts, 1)

            # Plot raw PPG
            plt.figure(figsize=(8, 3), dpi=300)
            plt.plot(T, xf, color='blue', label="Raw PPG")
            plt.xlabel("Time (seconds)", fontsize=14)
            plt.ylabel("Amplitude", fontsize=14)
            # plt.title("Raw PPG Signal")
            plt.grid(True)
            plt.tight_layout()
            plt.xticks(fontsize=14)
            plt.yticks(fontsize=14)
            plt.savefig(os.path.join(STATIC_FOLDER, "ppg_plot.png"))
            plt.close()

            SQ = []     # equivalent to: SQ = zeros in MATLAB
            PR = []     # to store [rec, i, PR_o] for each block
            Esto = []   # to store quality-related parameters
            BN1 = 1  # BN1=1;

            for rec in range(xcn.shape[0]):  # for rec=1:size(xcn,1)
                val = xcn[rec, :]  # val=xcn(rec,:);

                Fs = 125  # Fs=125;
                Bck_size = 5  # Bck_size=5;
                L1 = len(val)  # L1=length(val);
                BL = int(Bck_size * Fs)  # BL=floor(Bck_size*Fs);
                N1 = 0  # N1=1;
                NE = N1 + BL  # NE=N1+BL-1;
                i = 1  # i=1;

                AMDF_h = int(2 * (60 * Fs) / 30)  # AMDF_h=2*(60*Fs)/30;
                th = 0.1  # th=0.1;
                thm = -0.1  # thm=-0.1;

                while NE <= L1:  # while (NE<=L1)
                    x1 = val[N1:NE]  # xo=val(N1:NE);
                    N1 = NE  # N1=NE+1;
                    NE = N1 + BL  # NE=N1+BL-1;

                    famp = np.max(np.abs(x1))  # [famp,~]=max(abs(xo));
                    xo = x1 / famp  # xo=xo/famp;

                    b0, a0 = cheby1(5, 0.001, 1 / Fs, btype='high')  # [b0,a0]=cheby1(5,0.001,1/Fs,"high");
                    xo = filtfilt(b0, a0, xo)  # xo = filtfilt(b0, a0, xo);
                    xo = xo / np.max(np.abs(xo))  # xo=xo/max(abs(xo));

                    xd = np.diff(xo)  # xd=diff(xo);
                    b1 = np.ones(3) / 3  # b1=rectwin(3)./3;
                    a1 = 1  # a1=1;
                    xs = filtfilt(b1, a1, xd)  # xs=filtfilt(b1,a1,xd);

                    PZC, S1 = msm_zerocros(xs, 'all')  # [PZC,S1]=msm_zerocros(xs,'all');
                    NPZCR = len(PZC)  # NPZCR=numel(PZC);

                    AMDFo = siv_AMDF_04(xo, Fs)  # AMDFo=siv_AMDF_04(xo,Fs);
                    AMDFo = AMDFo[:AMDF_h]  # AMDFo=AMDFo(1:AMDF_h);
                    AMDFo = AMDFo - np.mean(AMDFo)  # AMDFo=AMDFo-mean(AMDFo);
                    famp = np.max(np.abs(AMDFo))  # [famp,~]=max(abs(AMDFo));
                    AMDFo = AMDFo / famp  # AMDFo=AMDFo/famp;

                    sam_o = np.arange(1, len(AMDFo) + 1)  # sam_o=1:length(AMDFo);

                    _, locs2 = siv_peakanno_AMDF(-AMDFo)  # [~,locs2] = siv_peakanno_AMDF(-AMDFo);

                    if locs2[0] > 15 and locs2[0] <= AMDF_h - 15:  # if locs2(1)>15 && locs2(1)<=AMDF_h-15
                        window = AMDFo[locs2[0] - 10: locs2[0] + 11]  # [~,ref]=min(AMDFo(locs2(1)-10:locs2(1)+10));
                        ref = np.argmin(window)
                        locs2[0] = ref + locs2[0] - 10  # locs2(1)=ref+locs2(1)-11;

                    PR_o = int(np.floor(60 * Fs / locs2[0]))  # PR_o=floor(60*Fs/locs2(1));

                    cross_th_o = siv_th_cross(xo, 'b', th)  # cross_th_o=siv_th_cross(xo,'b',th);
                    cross_thm_o = siv_th_cross(xo, 'b', thm)  # cross_thm_o=siv_th_cross(xo,'b',thm);

                    N = len(locs2)  # N=length(locs2);
                    if locs2[0] == 1 or locs2[1] == 1:  # if (locs2(1)==1 || locs2(2)==1)
                        N = 0  # N=0;

                    mag = abs(len(cross_th_o) - len(cross_thm_o))  # mag=abs(length(cross_th_o)-length(cross_thm_o));
                            # Esto(BN1,1:7+length(locs2))=[rec,i,length(cross_th_o),length(cross_thm_o),N,AMDFo(locs2(1)),AMDFo(locs2(2)),locs2];
                    est = [rec + 1, i, len(cross_th_o), len(cross_thm_o), N, AMDFo[locs2[0]], AMDFo[locs2[1]], *locs2]

                    # MATLAB uses preallocated matrix, in Python we usually append
                    Esto.append(est)

                    # mag=abs(length(cross_th_o)-length(cross_thm_o));
                    mag = abs(len(cross_th_o) - len(cross_thm_o))

                    # if (NPZCR>8 && NPZCR<=38)
                    if NPZCR > 8 and NPZCR <= 38:
                        SQ.append(0)  # SQ(BN1,1)=0;

                    # elseif (NPZCR>38 && NPZCR<168)
                    elif NPZCR > 38 and NPZCR < 168:
                        SQ.append(1)  # SQ(BN1,1)=1;

                    # elseif (N<2 || PR_o<30 || PR_o>300)
                    elif N < 2 or PR_o < 30 or PR_o > 300:
                        SQ.append(1)  # SQ(BN1,1)=1;

                    # elseif ((AMDFo(locs2(1))>0.13 && AMDFo(locs2(2))>-0.35) && mag>64)
                    elif (AMDFo[locs2[0]] > 0.13 and AMDFo[locs2[1]] > -0.35 and mag > 64):
                        SQ.append(1)  # SQ(BN1,1)=1;

                    # elseif ((AMDFo(locs2(1))<0.37 && AMDFo(locs2(2))<-0.34) && mag<=9)
                    elif (AMDFo[locs2[0]] < 0.37 and AMDFo[locs2[1]] < -0.34 and mag <= 9):
                        SQ.append(0)  # SQ(BN1,1)=0;

                    # else
                    else:
                        # range=[0,locs2];
                        range_vals = [0] + locs2

                        # distance=diff(range);
                        distance = np.diff(range_vals)

                        # dist=diff(distance);
                        dist = np.diff(distance)

                        # for k=1:length(dist)
                        flag = 0
                        for k in range(len(dist)):
                            # if (dist(k)>8)
                            if dist[k] > 8:
                                SQ.append(1)  # SQ(BN1,1)=1;
                                flag = 1
                                break
                        if flag == 0:
                            SQ.append(0)
                            

                    # PR(BN1,:)=[rec,i,PR_o];
                    PR.append([rec + 1, i, PR_o])

                    # i=i+1;
                    i += 1

                    # BN1=BN1+1;
                    BN1 += 1
            SQ = np.atleast_1d(np.array(SQ))

            # Count and print number of good quality signals (SQ == 0)
            good_quality_count = len([s for s in SQ if s == 0])
            print(f"Good Quality Signals: {good_quality_count}")

            # Count and print number of bad quality signals (SQ == 1)
            bad_quality_count = len([s for s in SQ if s == 1])
            print(f"Bad Quality Signals: {bad_quality_count}")
            
            #============================
            # Signal quality rule: SQ == 0 means good
            #============================

            if SQ[0] == 0:
                quality = "Good"
            else:
                quality = "Bad"

            #============================
            # Pulse Rate
            #============================

            pulse_rate = PR[0][2]
            print(f"Pulse Rate: {pulse_rate}")

            #============================
            # peak detection logic
            #============================

            try:
                # Use custom rhythm + peak detection logic
                RTHB = 0.25
                th2 = 0.15
                loc1, pk1, loc2_foot, pk1_foot = rhyth_sp_onset_post_processing_new3rules_modified(xf, th2, RTHB)
                loc1 = list(loc1)
                loc2_foot = list(loc2_foot)

                if loc1[0] > loc2_foot[0] and loc1[-1] < loc2_foot[-1]:
                    TEMP = len(loc1)
                elif loc1[0] < loc2_foot[0] and loc1[-1] < loc2_foot[-1]:
                    loc1 = loc1[1:]
                    TEMP = len(loc1)
                elif loc1[0] < loc2_foot[0] and loc1[-1] > loc2_foot[-1]:
                    loc1 = loc1[1:-1]
                    TEMP = len(loc1)
                elif loc1[0] > loc2_foot[0] and loc1[-1] > loc2_foot[-1]:
                    loc1 = loc1[:-1]
                    TEMP = len(loc1)
                else:
                    TEMP = len(loc1)
                
                print(loc1)

                # Check minimum peaks
                if len(loc1) < 2:
                    raise ValueError("Too few peaks for analysis.")

                #============================
                # Rhythm classification
                #============================

                # Select the first row only
                sig1 = df  # shape = (1, 625)

                # Sampling settings
                Fs = 125
                Bck_size = 5
                BL = int(Bck_size * Fs)

                # Initialize variables
                BBI1EST = []
                MuIR_HR_ESTAB = MuIR_HR_ESTNR = 0
                DIR_HR_ESTAB = DIR_HR_ESTN = 0
                EEventCBC = EEventCTC = EEventCNR = 0
                EEventABC = EEventATC = EEventANR = 0

                EST_Rhythm_Avg = []
                EST_Rhythm_Diff = []
                ESTC_HR_Class = []
                ESTA_HR_Class = []
                TPresult = []
                Total_Peaks = []

                for j in range(sig1.shape[0]):  # This will loop only once
                    xo = sig1.iloc[j, :].values  # shape: (625,)    
                    # Now process xo (your segment)
                    print(f"Processing segment {j+1}, length = {len(xo)}")
                    # Example: Normalize
                    xo = xo / np.max(np.abs(xo))
                    b0, a0 = cheby1(5, 0.001, 1 / Fs, 'high')
                    xo = filtfilt(b0, a0, xo)
                    xo = xo / np.max(np.abs(xo))

                    N = int(0.2 * Fs)
                    w = gaussian(N, std=7)
                    dw = np.gradient(w)
                    dQRS = filtfilt(dw, [1], xo)

                    xQRS_Norm = dQRS / np.max(np.abs(dQRS))
                    xQRS_Norm_th = (xQRS_Norm > 0.05) * xQRS_Norm + np.finfo(float).eps
                    SE = -(xQRS_Norm_th**2) * np.log2(xQRS_Norm_th**2)
                    MA_L = int(0.2 * Fs)
                    SEE_smooth = filtfilt(np.ones(MA_L)/MA_L, [1], SE)
                    SEE_smooth /= np.max(np.abs(SEE_smooth))

                    th_amp2 = np.mean(SEE_smooth)
                    SEE_smooth = SEE_smooth * (SEE_smooth > th_amp2)

                    dSEE_smooth = np.gradient(SEE_smooth)
                    dSEE_smooth = filtfilt(np.ones(int(0.2*Fs))/int(0.2*Fs), [1], dSEE_smooth)

                    PZCP, _ = msm_zerocros(dSEE_smooth, 'n')

                    WS = int(0.05 * Fs)
                    min_dist = int(0.1 * Fs)
                    min_amp = 0.3

                    xn4 = np.concatenate((np.zeros(2 * WS + 1), xo, np.zeros(2 * WS + 1)))
                    PZCP = [p + 2 * WS for p in PZCP]
                    PZCP_Correct = []

                    for p in PZCP:
                        start = p - 2 * WS
                        end = p + WS
                        if start > 0 and end < len(xn4):
                            segment = xn4[start:end]
                            peak_idx = np.argmax(segment)
                            corrected = peak_idx + start - (2 * WS) - 1
                            if segment[peak_idx] > min_amp:
                                PZCP_Correct.append(corrected)

                    # Remove close or out-of-range peaks
                    PZCP_Correct = sorted(set([
                        p for i, p in enumerate(PZCP_Correct)
                        if (i == 0 or p - PZCP_Correct[i - 1] > min_dist) and (0 < p < len(xo))
                    ]))

                    Total_Peaks.append([len(PZCP_Correct)])
                    BBI1EST.extend(PZCP_Correct)

                    HR1EST = 12 * len(PZCP_Correct)

                    if len(PZCP_Correct) > 1:
                        DPEST = np.diff(PZCP_Correct)
                        HR2EST = int((60 * Fs) / np.mean(DPEST))
                        BeatHR_EST = (60 * Fs) / DPEST
                        MuHR_EST = np.mean(BeatHR_EST)
                    else:
                        HR2EST = 0
                        BeatHR_EST = np.array([0])
                        MuHR_EST = 0

                    MeanCHR_EST = np.sum(np.abs(BeatHR_EST - MuHR_EST) > 4)
                    MuIR_HR_EST = MeanCHR_EST > 1
                    MuIR_HR_ESTAB += MuIR_HR_EST
                    MuIR_HR_ESTNR += (1 - MuIR_HR_EST)
                    EST_Rhythm_Avg.append(MuIR_HR_EST)

                    BeatHR_ESTD = np.abs(np.diff(BeatHR_EST))
                    DCHR_EST = np.sum(BeatHR_ESTD > 4)
                    DIR_HR_EST = DCHR_EST > 1
                    DIR_HR_ESTAB += DIR_HR_EST
                    DIR_HR_ESTN += (1 - DIR_HR_EST)
                    EST_Rhythm_Diff.append(DIR_HR_EST)

                    EEventC = 0 if HR1EST <= 60 else 1 if HR1EST > 100 else 2
                    if EEventC == 0:
                        EEventCBC += 1
                    elif EEventC == 1:
                        EEventCTC += 1
                    else:
                        EEventCNR += 1
                    ESTC_HR_Class.append(EEventC)

                    EEventA = 0 if HR2EST <= 60 else 1 if HR2EST > 100 else 2
                    if EEventA == 0:
                        EEventABC += 1
                    elif EEventA == 1:
                        EEventATC += 1
                    else:
                        EEventANR += 1
                    ESTA_HR_Class.append(EEventA)

                    #TPresult.append([j + 1, len(PZCP_Correct)])


                print("\n--- Estimated Rhythm (Per Segment) ---")
                for idx, val in enumerate(EST_Rhythm_Diff):
                    status = "Regular" if val == 0 else "Irregular"
                    print(f"Segment {idx + 1}: {status}")

                # Calculate peak-to-peak intervals
                # peak_intervals = np.diff([T[i] for i in loc1])
                # HR = round(60 / np.mean(peak_intervals), 2) if len(peak_intervals) > 0 else 0

                # Rhythm classification
                # rhythm_std = np.std(peak_intervals)
                # rhythm = "Regular" if rhythm_std < 0.1 else "Irregular"

                # # Signal quality rule
                # quality = "Good" if len(loc1) >= 5 and rhythm == "Regular" else "Bad"

                # # BP class logic
                # if HR < 60:
                #     bp_class = "Hypo"
                # elif HR <= 100:
                #     bp_class = "Norm"
                # else:
                #     bp_class = "Hyper"

                # Plot PPG with peaks
                plt.figure(figsize=(11, 3), dpi=300)
                plt.plot(T, xf,color='blue', label="PPG")
                plt.plot([T[i] for i in loc1], [xf[i] for i in loc1], 'r^', label="Detected Systolic Peaks")
                # plt.plot([T[i] for i in loc2_foot], [xf[i] for i in loc2_foot], 'go', label="Foot Points")
                plt.xlabel("Time (seconds)", fontsize=14)
                plt.ylabel("Amplitude", fontsize=14)
                # plt.title("PPG with Peaks")
                # plt.legend()
                # plt.legend(loc='upper', bbox_to_anchor=(1.05, 1))
                plt.legend(loc='center', bbox_to_anchor=(0.5, 1.15), ncol=2, fontsize=14)
                plt.grid(True)
                plt.tight_layout()
                plt.xticks(fontsize=14)
                plt.yticks(fontsize=14)
                plt.savefig(os.path.join(STATIC_FOLDER, "ppg_peaks_plot.png"))
                plt.close()
                
                #============================
                # BP CLassifiaction
                #============================

                x321=xcn

                # Sampling and time vector
                Ts = 1 / 125
                T = np.arange(0, 8, Ts)

                # Storage containers
                failed_segments = []
                x = 0

                avg_PPI, avg_MP, avg_FA, avg_DT, avg_CT = [], [], [], [], []
                avg_SA, avg_DA, avg_TA, avg_MS, avg_FFI = [], [], [], [], []
                avg_RCT, avg_RDT = [], []
                

                for j in range(x321.shape[0]):
                    try: 
                        xf = x321[j, 1:626]  # MATLAB 2:625 -> Python 1:626
                        RTHB = 0.25
                        th2 = 0.15

                        loc1, pk1, loc2_foot, pk1_foot = sp_onset_post_processing_new3rules_modified(xf, th2, RTHB)
                        loc1 = list(loc1)
                        loc2_foot = list(loc2_foot)

                        if loc1[0] > loc2_foot[0] and loc1[-1] < loc2_foot[-1]:
                            TEMP = len(loc1)
                        elif loc1[0] < loc2_foot[0] and loc1[-1] < loc2_foot[-1]:
                            loc1 = loc1[1:]
                            TEMP = len(loc1)
                        elif loc1[0] < loc2_foot[0] and loc1[-1] > loc2_foot[-1]:
                            loc1 = loc1[1:-1]
                            TEMP = len(loc1)
                        elif loc1[0] > loc2_foot[0] and loc1[-1] > loc2_foot[-1]:
                            loc1 = loc1[:-1]
                            TEMP = len(loc1)
                        else:
                            TEMP = len(loc1)

                        peak_to_peak = [T[loc1[i+1]] - T[loc1[i]] for i in range(TEMP - 1)]
                        avg_PPI.append(np.mean(peak_to_peak))

                        mean_peak = [xf[loc1[i]] for i in range(TEMP - 1)]
                        avg_MP.append(np.mean(mean_peak))

                        dias_time_period = [T[loc2_foot[i+1]] - T[loc1[i]] for i in range(TEMP)]
                        avg_DT.append(np.mean(np.abs(dias_time_period)))
                        mean_diastolic_amp = [xf[loc2_foot[i+1]] for i in range(TEMP)]
                        avg_FA.append(np.mean(mean_diastolic_amp))

                        sys_time_period = [T[loc1[i]] - T[loc2_foot[i]] for i in range(TEMP)]
                        avg_CT.append(np.mean(sys_time_period))

                        P_t_sum_1 = [np.sum(np.abs(xf[loc2_foot[i]:loc1[i]+1]) * Ts) for i in range(TEMP)]
                        avg_SA.append(np.mean(P_t_sum_1))
                        P_t_sum_2 = [np.sum(np.abs(xf[loc1[i]+1:loc2_foot[i+1]]) * Ts) for i in range(TEMP)]
                        avg_DA.append(np.mean(P_t_sum_2))
                        P_t_sum_3 = [np.sum(np.abs(xf[loc2_foot[i]:loc2_foot[i+1]]) * Ts) for i in range(TEMP)]
                        avg_TA.append(np.mean(P_t_sum_3))

                        F = [(loc1[i] + loc2_foot[i]) // 2 for i in range(TEMP)]
                        avg_MS.append(np.mean([xf[f] for f in F]))

                        foot_to_foot = [T[loc2_foot[i+1]] - T[loc2_foot[i]] for i in range(TEMP)]
                        avg_FFI.append(np.mean(foot_to_foot))

                        Relative_CT = [sys_time_period[i] / foot_to_foot[i] for i in range(TEMP)]
                        Relative_DT = [abs(dias_time_period[i]) / foot_to_foot[i] for i in range(TEMP)]
                        avg_RCT.append(np.mean(Relative_CT))
                        avg_RDT.append(np.mean(Relative_DT))

                        x += 1
                        
                    except Exception as e:
                        print(f"Error processing segment {j+1}: {e}")
                        failed_segments.append(j+1)
                        continue

                # Stack features and save
                SBP_PPG_Feat = np.array([
                    avg_PPI, avg_MP, avg_FA, avg_DT, avg_CT, avg_SA,
                    avg_DA, avg_TA, avg_MS, avg_FFI, avg_RCT, avg_RDT
                ]).T

                # Convert to DataFrame
                df_SBP_PPG_Feat = pd.DataFrame(SBP_PPG_Feat)

                from sklearn.model_selection import train_test_split
                from sklearn.linear_model import LogisticRegression
                from sklearn.tree import DecisionTreeClassifier
                from sklearn.svm import SVC
                from sklearn.ensemble import RandomForestClassifier
                from sklearn.naive_bayes import MultinomialNB
                from sklearn.neighbors import KNeighborsClassifier
                from sklearn.neural_network import MLPClassifier
                from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
                import joblib
                from sklearn.model_selection import RandomizedSearchCV, GridSearchCV, train_test_split
                from sklearn.datasets import make_classification
                # import xgboost
                # from xgboost import XGBClassifier
                from sklearn.ensemble import AdaBoostClassifier
                from sklearn.ensemble import BaggingClassifier
                from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

                dataset_test0=df_SBP_PPG_Feat[:]
                dataset_test00=dataset_test0.assign(output=0)
                dataset_test=dataset_test00.dropna()

                XX_test = dataset_test.iloc[0:,0:12]
                YY_test = dataset_test[['output']]
                model4=joblib.load('uploads\model4_best_Feat_raw.joblib')
                # (Hypo[0], Norm[1], Hyper[2])
                YY_pred_4 = model4.predict(XX_test)
                # conf_matrix = confusion_matrix(YY_test, YY_pred_4)
                # print(conf_matrix)
                print(YY_pred_4)

                # Class mapping
                class_names = {0: 'Hypotension', 1: 'Normotension', 2: 'Hypertension'}

                # Print predictions with class names
                for i, pred in enumerate(YY_pred_4):
                    print(f"Sample {i}: {pred} → {class_names[pred]}")

                bp_class = class_names[pred]


                #============================
                # Pulse-to-pulse Interval Analysis
                #============================

                # ------- Simulated IBI from peak positions (in samples) --------
                # Replace this with your actual IBI vector if already computed
                Fs = 125  # Sampling rate in Hz
                # PZCP_Correct should contain R-peaks or PPG peaks in sample indices
                # For demo: Let's assume 1-second apart peaks over 10 seconds
                # PZCP_Correct = np.array([0, 125, 250, 375, 500, 625, 750, 875, 1000, 1125])  
                ib = np.diff(PZCP_Correct) * 1000 / Fs  # IBI in milliseconds
                # np.savetxt('ib1.csv', ib, delimiter=',')

                # ----------- Replace this line with your actual IBI array -----------
                #ib = np.loadtxt('ib1.csv', delimiter=',')  # Load IBI (in ms)

                ib = ib.flatten()

                # ------------------- Time Domain HRV Analysis -----------------------
                TD_HRV = {}

                # TD_HRV['Total Duration (s)'] = sum(ib) / 1000  # total duration in seconds
                # TD_HRV['CountPP'] = ib.size
                # TD_HRV['MinPP'] = ib.min()
                # TD_HRV['MaxPP'] = ib.max()
                TD_HRV['MeanPP'] = ib.mean()
                # TD_HRV['MedianPP'] = np.median(ib)
                # TD_HRV['RangePP'] = ib.max() - ib.min()

                # ---- Segmentation function (modified for 5-sec) ----
                def segmentation(ib=None, duration=5):
                    tn = np.cumsum(ib)
                    max_time = tn[-1]
                    duration *= 1000  # convert to ms
                    limits = np.arange(0, max_time + duration, duration)
                    cindex = 0
                    segments = []
                    for i, _ in enumerate(range(0, limits.size - 1)):
                        csegment = []
                        while np.sum(csegment) < duration:
                            csegment.append(ib[cindex])
                            if cindex < ib.size - 1:
                                cindex += 1
                            else:
                                break
                        if np.sum(csegment) > duration:
                            csegment = csegment[:-1]
                            cindex -= 1
                        segments.append(list(csegment))
                    return segments, True

                # ---- SDPP Index ----
                def std_dev(numbers):
                    n = len(numbers)
                    if n < 2:
                        return 0
                    mean = sum(numbers) / n
                    squared_diff = [(x - mean) ** 2 for x in numbers]
                    variance = sum(squared_diff) / (n - 1)
                    return np.sqrt(variance)

                def sdnn_index(ib=None, duration=5):
                    segments, seg = segmentation(ib, duration=duration)
                    if seg:
                        sdnn_values = [std_dev(x) for x in segments]
                        return np.mean(sdnn_values)
                    else:
                        return float('nan')

                TD_HRV['SDPP'] = std_dev(ib)
                # TD_HRV['SDPP_NP'] = ib.std()
                # TD_HRV['SDPPI'] = sdnn_index(ib)

                # ---- SDAPP ----
                def sdann(ib=None, duration=5):
                    segments, _ = segmentation(ib, duration=duration)
                    mean_values = [np.mean(x) for x in segments]
                    return std_dev(mean_values)

                # TD_HRV['SDAPP'] = sdann(ib)

                # ---- Successive Differences ----
                PP_diff = np.abs(np.diff(ib))
                # TD_HRV['MinPPD'] = PP_diff.min()
                # TD_HRV['MaxPPD'] = PP_diff.max()
                # TD_HRV['MeanPPD'] = PP_diff.mean()
                # TD_HRV['MedianPPD'] = np.median(PP_diff)
                RMSSD = np.sqrt(np.sum(PP_diff**2) / PP_diff.size)
                TD_HRV['RMSSD'] = RMSSD

                # ---- MADPP, SDSD ----
                medianRR = np.median(ib)
                MADPP = np.median(np.abs(ib - medianRR))
                # TD_HRV['MADPP'] = MADPP
                # TD_HRV['SDSD'] = PP_diff.std()

                # ---- Coefficients of Variation ----
                # TD_HRV['CVPP'] = ib.std() / ib.mean()

                def MCVPP(ib=None, duration=5):
                    segments, _ = segmentation(ib, duration=duration)
                    CVPP_vals = [np.std(x) / np.mean(x) for x in segments if np.mean(x) > 0]
                    return np.median(CVPP_vals)

                # TD_HRV['MCVPP'] = MCVPP(ib)
                # TD_HRV['CVSD'] = RMSSD / ib.mean()
                # TD_HRV['MAD/Median'] = MADPP / np.median(ib)

                # ---- IQR ----
                def interquartile_range(arr):
                    q75, q25 = np.percentile(arr, [75, 25])
                    return q75 - q25

                # TD_HRV['IQR'] = interquartile_range(ib)
                # TD_HRV['SDRMSSD'] = TD_HRV['SDPP'] / RMSSD
                # TD_HRV['Prc20PP'] = np.percentile(ib, 20)
                # TD_HRV['Prc80PP'] = np.percentile(ib, 80)

                # ---- PP20, PP50 ----
                PP20 = np.sum(PP_diff > 20)
                PP50 = np.sum(PP_diff > 50)
                # TD_HRV['PP20'] = PP20
                # TD_HRV['PPPP20'] = PP20 / len(PP_diff) * 100
                TD_HRV['PP50'] = PP50
                TD_HRV['PPPP50'] = PP50 / len(PP_diff) * 100

                # ---- Heart Rate Metrics ----
                HR = 60000. / ib
                # TD_HRV['HR_min'] = HR.min()
                # TD_HRV['HR_max'] = HR.max()
                TD_HRV['HR_mean'] = HR.mean()
                TD_HRV['HR_STD'] = HR.std()

                # ---- Round & Print ----
                for key in TD_HRV:
                    TD_HRV[key] = round(TD_HRV[key], 3)

                for key, value in TD_HRV.items():
                    print(f"{key}: {value}")
                # # ---- Save to CSV ----
                # def save_dict_to_csv(dictionary, file_name):
                #     with open(file_name, 'w', newline='') as f:
                #         writer = csv.writer(f)
                #         writer.writerow(['Metric', 'Value'])
                #         for k, v in dictionary.items():
                #             writer.writerow([k, v])

                # save_dict_to_csv(TD_HRV, 'TD_HRV_5sec.csv')

                #============================
                # Render with results
                #============================
                return render_template("index.html",
                                       sampling_rate=Fs,
                                       duration=duration,
                                       signal_quality=quality,
                                       pulse_rate=pulse_rate,
                                       rhythm=status,
                                       bp_class=bp_class,
                                       MeanPP=TD_HRV['MeanPP'],
                                       SDPP=TD_HRV['SDPP'],
                                       RMSSD=TD_HRV['RMSSD'],
                                       PP50=TD_HRV['PP50'],
                                       PPPP50=TD_HRV['PPPP50'])
                                    #    HR_mean=TD_HRV['HR_mean'],
                                    #    HR_STD=TD_HRV['HR_STD'])
            except Exception as e:
                print("Processing error:", e)
                return render_template("index.html", error="Signal processing failed.")

    # GET request or initial load
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
