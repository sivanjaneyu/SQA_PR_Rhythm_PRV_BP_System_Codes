import numpy as np
from scipy.signal import filtfilt

def siv_AMDF_04(x, Fs):
    # Step 1: Get the length of the signal
    N = len(x)  # Same as MATLAB's N=length(x);

    # Step 2: Initialize the output array D with zeros, of size (N-1)
    D = np.zeros(N - 1)  # MATLAB's D(k)=0 for each k

    # Step 3: Outer loop over lag values k = 1 to N-1
    for k in range(1, N):  # MATLAB: for k=1:N-1
        # Inner loop: compute sum of |x(n) - x(n+k)| for n = 0 to N-k-1
        for n in range(N - k):  # MATLAB: for n=1:N-k (0-indexed in Python)
            # Accumulate the absolute differences
            D[k - 1] += abs(x[n] - x[n + k])  # MATLAB: abs(x(n)-x(n+k))

        # Step 4: Average the sum over the number of terms
        D[k - 1] = D[k - 1] / (N - k)  # MATLAB: D(k)=D(k)/(N-k);

    return D

def siv_moving_avg_fil(x, N):
    # Line 1: x = input signal, N = window size
    # (Already handled in function arguments)

    # Line 2: Create moving average filter kernel of length N
    b = np.ones(N) / N  # Equivalent to MATLAB's b = ones(N, 1)/N

    # Line 3: Apply zero-phase filtering using filtfilt
    y = filtfilt(b, 1, x)  # Forward and backward filtering

    # Line 4: Return filtered signal
    return y

def siv_neg_zero_cross(ydif):
    zerocross = []
    i = 1  # start from index 1 to mimic MATLAB's 1-based indexing

    while i < len(ydif) - 1:
        # Check for negative-going threshold crossing at -0.25
        if ydif[i] > -0.25 and ydif[i + 1] <= -0.25:
            # Choose between i-1 and i based on magnitude
            if abs(ydif[i]) > abs(ydif[i - 1]):
                zerocross.append(i - 1)
            else:
                zerocross.append(i)
        i += 1

    # If no crossings found, assign default
    if len(zerocross) == 0:
        zerocross = [1, 1]

    # If first crossing is too early, discard it
    if zerocross[0] <= 5:
        zerocross = zerocross[1:]

    # Recheck again in case list became empty after above operation
    if len(zerocross) == 0:
        zerocross = [1, 1]

    # Ensure at least 2 elements
    if len(zerocross) == 1:
        zerocross.append(1)

    return zerocross


def siv_peakanno_AMDF(ym):
    # Step 1: Compute the gradient (derivative)
    ydif = np.gradient(ym)

    # Optional smoothing (commented out in MATLAB)
    # ydif = siv_moving_avg_fil(ydif, 3)

    # Step 2: Zero out the first three samples
    ydif[:3] = 0

    # Step 3: Normalize to maximum absolute value
    max_val = np.max(np.abs(ydif))
    if max_val != 0:
        ydif = ydif / max_val

    # Step 4: Find negative zero-crossings
    zerocross = siv_neg_zero_cross(ydif)

    # Step 5: Handle case where zerocross[0] == 1
    if zerocross[0] == 1:
        zerocross[0] = np.max(ym)  # Replace with peak value

    return ydif, zerocross


def siv_th_cross(x, m='b', th=0.1):
    s = x >= th  # Step 1: Thresholding
    k = s[1:].astype(int) - s[:-1].astype(int)  # Step 2: Transitions (diff)

    if 'p' in m:  # Positive edge crossing
        f = np.where(k > 0)[0]
    elif 'n' in m:  # Negative edge crossing
        f = np.where(k < 0)[0]
    else:  # Any crossing
        f = np.where(k != 0)[0]

    return f + 1  # MATLAB uses f+1 due to indexing

def msm_zerocros(x, mode='p'):
    x = np.asarray(x)
    s = x >= 0
    k = np.diff(s.astype(int))
    if 'p' in mode:
        f = np.where(k > 0)[0]
    elif 'n' in mode:
        f = np.where(k < 0)[0]
    else:
        f = np.where(k != 0)[0]
    zcr = f
    slope = x[f + 1] - x[f] if len(f) > 0 else np.array([0])
    if len(zcr) == 0:
        zcr = np.array([0])
    return zcr, slope


def peak_onset_tcr_CS(xbo, th2):
    spT, spAT, onsetT, onsetAT = [], [], [], []

    xb1 = [1 if val > th2 else -1 for val in xbo]
    xb1 = np.array(xb1) - np.mean(xb1)

    nzcrf, _ = msm_zerocros(xb1, 'n')
    pzcrf, _ = msm_zerocros(xb1, 'p')

    totalzcrf = len(nzcrf) + len(pzcrf)
    lzcrf = min(len(nzcrf), len(pzcrf))

    if len(pzcrf) > len(nzcrf):
        if nzcrf[0] > pzcrf[0]:
            for i in range(lzcrf):
                spa = np.max(xbo[pzcrf[i]:nzcrf[i]+1])
                spl1 = np.argmax(xbo[pzcrf[i]:nzcrf[i]+1])
                sp = pzcrf[i] + spl1
                spT.append(sp)
                spAT.append(spa)

                onseta = np.min(xbo[nzcrf[i]:pzcrf[i+1]+1])
                onsetl1 = np.argmin(xbo[nzcrf[i]:pzcrf[i+1]+1])
                onset = nzcrf[i] + onsetl1
                onsetT.append(onset)
                onsetAT.append(onseta)
        else:
            for i in range(lzcrf):
                spa = np.max(xbo[pzcrf[i]:nzcrf[i+1]+1])
                spl1 = np.argmax(xbo[pzcrf[i]:nzcrf[i+1]+1])
                sp = pzcrf[i] + spl1
                spT.append(sp)
                spAT.append(spa)

                onseta = np.min(xbo[nzcrf[i]:pzcrf[i]+1])
                onsetl1 = np.argmin(xbo[nzcrf[i]:pzcrf[i]+1])
                onset = nzcrf[i] + onsetl1
                onsetT.append(onset)
                onsetAT.append(onseta)
    else:
        if len(nzcrf) == len(pzcrf):
            if nzcrf[0] > pzcrf[0]:
                for i in range(lzcrf):
                    spa = np.max(xbo[pzcrf[i]:nzcrf[i]+1])
                    spl1 = np.argmax(xbo[pzcrf[i]:nzcrf[i]+1])
                    sp = pzcrf[i] + spl1
                    spT.append(sp)
                    spAT.append(spa)

                    if i <= lzcrf - 2:
                        onseta = np.min(xbo[nzcrf[i]:pzcrf[i+1]+1])
                        onsetl1 = np.argmin(xbo[nzcrf[i]:pzcrf[i+1]+1])
                        onset = nzcrf[i] + onsetl1
                        onsetT.append(onset)
                        onsetAT.append(onseta)
            else:
                for i in range(lzcrf):
                    if i <= lzcrf - 2:
                        spa = np.max(xbo[pzcrf[i]:nzcrf[i+1]+1])
                        spl1 = np.argmax(xbo[pzcrf[i]:nzcrf[i+1]+1])
                        sp = pzcrf[i] + spl1
                        spT.append(sp)
                        spAT.append(spa)

                    onseta = np.min(xbo[nzcrf[i]:pzcrf[i]+1])
                    onsetl1 = np.argmin(xbo[nzcrf[i]:pzcrf[i]+1])
                    onset = nzcrf[i] + onsetl1
                    onsetT.append(onset)
                    onsetAT.append(onseta)
        else:
            if nzcrf[0] > pzcrf[0]:
                for i in range(lzcrf):
                    spa = np.max(xbo[pzcrf[i]:nzcrf[i]+1])
                    spl1 = np.argmax(xbo[pzcrf[i]:nzcrf[i]+1])
                    sp = pzcrf[i] + spl1
                    spT.append(sp)
                    spAT.append(spa)

                    if i <= lzcrf - 2:
                        onseta = np.min(xbo[nzcrf[i]:pzcrf[i+1]+1])
                        onsetl1 = np.argmin(xbo[nzcrf[i]:pzcrf[i+1]+1])
                        onset = nzcrf[i] + onsetl1
                        onsetT.append(onset)
                        onsetAT.append(onseta)
            else:
                for i in range(lzcrf):
                    spa = np.max(xbo[pzcrf[i]:nzcrf[i+1]+1])
                    spl1 = np.argmax(xbo[pzcrf[i]:nzcrf[i+1]+1])
                    sp = pzcrf[i] + spl1
                    spT.append(sp)
                    spAT.append(spa)

                    onseta = np.min(xbo[nzcrf[i]:pzcrf[i]+1])
                    onsetl1 = np.argmin(xbo[nzcrf[i]:pzcrf[i]+1])
                    onset = nzcrf[i] + onsetl1
                    onsetT.append(onset)
                    onsetAT.append(onseta)

    return spT, spAT, onsetT, onsetAT



def sp_onset_post_processing_new3rules_modified(xbo, THB, RTHB):
    spT, spAT, onsetT, onsetAT = peak_onset_tcr_CS(xbo, THB)
    spT = np.array(spT)
    onsetT = np.array(onsetT)
    spAT = np.array(spAT)
    onsetAT = np.array(onsetAT)

    if spT[0] < onsetT[0]:
        # Rule 01
        PonsetT = []
        PonsetTL = []
        check = 0
        for i in range(len(onsetT)):
            if onsetAT[i] > 0:
                PonsetT.append(onsetT[i])
                PonsetTL.append(i)

        if len(PonsetT) >= 1:
            PonsetT = np.array(PonsetT)
            PonsetTL = np.array(PonsetTL)
            if len(PonsetT) == 1:
                if PonsetT[-1] == onsetT[-1]:
                    check = 1
                else:
                    CPspT = spT[PonsetTL + 1]
            else:
                if PonsetT[-1] == onsetT[-1] and PonsetT[-1] > spT[-1]:
                    CPspT = [spT[PonsetTL[i] + 1] for i in range(len(PonsetT) - 1)]
                else:
                    CPspT = spT[PonsetTL + 1]

            if check == 0:
                spT = np.setdiff1d(spT, CPspT)
                onsetT = np.setdiff1d(onsetT, PonsetT)
                spAT = xbo[spT]
                onsetAT = xbo[onsetT]

        # Rule 02
        NspT = []
        NspTL = []
        for i in range(1, len(spT)):
            if spAT[i] < 0:
                NspT.append(spT[i])
                NspTL.append(i)

        if len(NspT) >= 1:
            CNonsetT = onsetT[np.array(NspTL) - 1]
            spT = np.setdiff1d(spT, NspT)
            onsetT = np.setdiff1d(onsetT, CNonsetT)
            spAT = xbo[spT]
            onsetAT = xbo[onsetT]

        # Rule 03
        exsp = 0
        RspT = []
        for i in range(2, len(spT)):
            if spAT[i] < RTHB * spAT[i - 1]:
                RspT.append(i)
                spT[i] = spT[i - 1]
                spAT[i] = xbo[spT[i]]
                exsp += 1

        spT = np.unique(spT)
        spAT = xbo[spT]

        if exsp >= 1:
            RonsetTL = np.array(RspT) - 1
            RonsetT = onsetT[RonsetTL]
            onsetT = np.setdiff1d(onsetT, RonsetT)
            onsetAT = xbo[onsetT]

    else:
        # Rule 01
        PonsetT = []
        PonsetTL = []
        check = 0
        for i in range(len(onsetT)):
            if onsetAT[i] > 0:
                PonsetT.append(onsetT[i])
                PonsetTL.append(i)

        if len(PonsetT) >= 1:
            PonsetT = np.array(PonsetT)
            PonsetTL = np.array(PonsetTL)
            if len(PonsetT) == 1:
                if PonsetT[-1] == onsetT[-1]:
                    check = 1
                else:
                    CPspT = spT[PonsetTL]
            else:
                if PonsetT[-1] == onsetT[-1] and PonsetT[-1] > spT[-1]:
                    CPspT = [spT[PonsetTL[i]] for i in range(len(PonsetT) - 1)]
                else:
                    CPspT = spT[PonsetTL]

            if check == 0:
                spT = np.setdiff1d(spT, CPspT)
                onsetT = np.setdiff1d(onsetT, PonsetT)
                spAT = xbo[spT]
                onsetAT = xbo[onsetT]

        # Rule 02
        NspT = []
        NspTL = []
        for i in range(len(spT)):
            if spAT[i] < 0:
                NspT.append(spT[i])
                NspTL.append(i)

        if len(NspT) >= 1:
            CNonsetT = onsetT[NspTL]
            spT = np.setdiff1d(spT, NspT)
            onsetT = np.setdiff1d(onsetT, CNonsetT)
            spAT = xbo[spT]
            onsetAT = xbo[onsetT]

        # Rule 03
        exsp = 0
        RspT = []
        for i in range(1, len(spT)):
            if spAT[i] < RTHB * spAT[i - 1]:
                RspT.append(i)
                spT[i] = spT[i - 1]
                spAT[i] = xbo[spT[i]]
                exsp += 1

        spT = np.unique(spT)
        spAT = xbo[spT]

        if exsp >= 1:
            RonsetTL = np.array(RspT)
            RonsetT = onsetT[RonsetTL]
            onsetT = np.setdiff1d(onsetT, RonsetT)
            onsetAT = xbo[onsetT]

    NewspT = spT
    NewonsetT = onsetT
    NewspAT = xbo[NewspT]
    NewonsetAT = xbo[NewonsetT]

    return NewspT, NewspAT, NewonsetT, NewonsetAT
    

def rhyth_peak_onset_tcr_CS(xbo, th2):
    spT, spAT, onsetT, onsetAT = [], [], [], []

    # Thresholding and binarization
    xb1 = np.where(xbo > th2, 1, -1)
    xb1 = xb1 - np.mean(xb1)

    # Zero-crossing detection
    nzcrf = np.where((xb1[:-1] > 0) & (xb1[1:] <= 0))[0] + 1  # negative zero crossings
    pzcrf = np.where((xb1[:-1] < 0) & (xb1[1:] >= 0))[0] + 1  # positive zero crossings

    lzcrf = min(len(nzcrf), len(pzcrf))

    if len(pzcrf) > len(nzcrf):
        if nzcrf[0] > pzcrf[0]:
            for i in range(lzcrf):
                spa = np.max(xbo[pzcrf[i]:nzcrf[i]])
                sp = pzcrf[i] + np.argmax(xbo[pzcrf[i]:nzcrf[i]])
                spT.append(sp)
                spAT.append(spa)

                onseta = np.min(xbo[nzcrf[i]:pzcrf[i+1]])
                onset = nzcrf[i] + np.argmin(xbo[nzcrf[i]:pzcrf[i+1]])
                onsetT.append(onset)
                onsetAT.append(onseta)
        elif nzcrf[0] < pzcrf[0]:
            first_start = 0
            first_end = nzcrf[0]
            spa = np.max(xbo[first_start:first_end+1])
            sp = first_start + np.argmax(xbo[first_start:first_end+1])
            spT.append(sp)
            spAT.append(spa)

            for i in range(lzcrf):
                spa = np.max(xbo[pzcrf[i]:nzcrf[i+1]])
                sp = pzcrf[i] + np.argmax(xbo[pzcrf[i]:nzcrf[i+1]])
                spT.append(sp)
                spAT.append(spa)

                onseta = np.min(xbo[nzcrf[i]:pzcrf[i]])
                onset = nzcrf[i] + np.argmin(xbo[nzcrf[i]:pzcrf[i]])
                onsetT.append(onset)
                onsetAT.append(onseta)

    elif len(nzcrf) == len(pzcrf):
        if nzcrf[0] > pzcrf[0]:
            for i in range(lzcrf):
                spa = np.max(xbo[pzcrf[i]:nzcrf[i]])
                sp = pzcrf[i] + np.argmax(xbo[pzcrf[i]:nzcrf[i]])
                spT.append(sp)
                spAT.append(spa)

                if i < lzcrf - 1:
                    onseta = np.min(xbo[nzcrf[i]:pzcrf[i+1]])
                    onset = nzcrf[i] + np.argmin(xbo[nzcrf[i]:pzcrf[i+1]])
                    onsetT.append(onset)
                    onsetAT.append(onseta)
        elif nzcrf[0] < pzcrf[0]:
            first_start = 0
            first_end = nzcrf[0]
            spa = np.max(xbo[first_start:first_end+1])
            sp = first_start + np.argmax(xbo[first_start:first_end+1])
            spT.append(sp)
            spAT.append(spa)

            for i in range(lzcrf):
                if i < lzcrf - 1:
                    spa = np.max(xbo[pzcrf[i]:nzcrf[i+1]])
                    sp = pzcrf[i] + np.argmax(xbo[pzcrf[i]:nzcrf[i+1]])
                    spT.append(sp)
                    spAT.append(spa)

                onseta = np.min(xbo[nzcrf[i]:pzcrf[i]])
                onset = nzcrf[i] + np.argmin(xbo[nzcrf[i]:pzcrf[i]])
                onsetT.append(onset)
                onsetAT.append(onseta)

    else:
        if nzcrf[0] > pzcrf[0]:
            for i in range(lzcrf):
                spa = np.max(xbo[pzcrf[i]:nzcrf[i]])
                sp = pzcrf[i] + np.argmax(xbo[pzcrf[i]:nzcrf[i]])
                spT.append(sp)
                spAT.append(spa)

                if i < lzcrf - 1:
                    onseta = np.min(xbo[nzcrf[i]:pzcrf[i+1]])
                    onset = nzcrf[i] + np.argmin(xbo[nzcrf[i]:pzcrf[i+1]])
                    onsetT.append(onset)
                    onsetAT.append(onseta)
        elif nzcrf[0] < pzcrf[0]:
            first_start = 0
            first_end = nzcrf[0]
            spa = np.max(xbo[first_start:first_end+1])
            sp = first_start + np.argmax(xbo[first_start:first_end+1])
            spT.append(sp)
            spAT.append(spa)

            for i in range(lzcrf):
                spa = np.max(xbo[pzcrf[i]:nzcrf[i+1]])
                sp = pzcrf[i] + np.argmax(xbo[pzcrf[i]:nzcrf[i+1]])
                spT.append(sp)
                spAT.append(spa)

                onseta = np.min(xbo[nzcrf[i]:pzcrf[i]])
                onset = nzcrf[i] + np.argmin(xbo[nzcrf[i]:pzcrf[i]])
                onsetT.append(onset)
                onsetAT.append(onseta)

    # Handle possible missing final peak at end
    if len(pzcrf) > 0 and len(nzcrf) > 0 and pzcrf[-1] > nzcrf[-1]:
        last_start = pzcrf[-1]
        last_end = len(xbo) - 1
        spa = np.max(xbo[last_start:last_end+1])
        sp = last_start + np.argmax(xbo[last_start:last_end+1])
        spT.append(sp)
        spAT.append(spa)

        onseta = np.min(xbo[nzcrf[-1]:sp+1])
        onset = nzcrf[-1] + np.argmin(xbo[nzcrf[-1]:sp+1])
        onsetT.append(onset)
        onsetAT.append(onseta)

    # Improved: check for missing starting peak before first pzcrf
    if len(pzcrf) > 0 and pzcrf[0] > 0:
        start_region = xbo[:pzcrf[0]]
        if len(start_region) > 1:
            spa = np.max(start_region)
            sp = np.argmax(start_region)
            spT = [sp] + spT
            spAT = [spa] + spAT

    # Improved: check for missed final peak and onset after last detected one
    if len(spT) > 0 and spT[-1] < len(xbo) - 3:
        end_region = xbo[spT[-1] + 1:]
        if len(end_region) > 1:
            spa = np.max(end_region)
            sp = spT[-1] + 1 + np.argmax(end_region)
            spT.append(sp)
            spAT.append(spa)

            last_onset_search_start = max(spT[-2], nzcrf[-1]) if len(spT) >= 2 and len(nzcrf) > 0 else 0
            onset_region = xbo[last_onset_search_start:sp+1]
            if len(onset_region) > 0:
                onseta = np.min(onset_region)
                onset = last_onset_search_start + np.argmin(onset_region)
                onsetT.append(onset)
                onsetAT.append(onseta)

    return spT, spAT, onsetT, onsetAT


def rhyth_sp_onset_post_processing_new3rules_modified(xbo, THB, RTHB):
    spT, spAT, onsetT, onsetAT = rhyth_peak_onset_tcr_CS(xbo, THB)
    spT, spAT = np.array(spT), np.array(spAT)
    onsetT, onsetAT = np.array(onsetT), np.array(onsetAT)

    if spT[0] < onsetT[0]:
        # Rule 01
        PonsetTL = np.where(onsetAT > 0)[0]
        PonsetT = onsetT[PonsetTL]
        check = 0

        if len(PonsetT) >= 1:
            if len(PonsetT) == 1:
                if PonsetT[-1] == onsetT[-1]:
                    check = 1
                else:
                    CPspT = spT[PonsetTL]
            else:
                if PonsetT[-1] == onsetT[-1] and PonsetT[-1] > spT[-1]:
                    CPspT = np.array([spT[PonsetTL[i]] for i in range(len(PonsetT)-1)])
                else:
                    CPspT = spT[PonsetTL]

            if check == 0:
                spT = np.setdiff1d(spT, CPspT)
                onsetT = np.setdiff1d(onsetT, PonsetT)
                spAT = xbo[spT]
                onsetAT = xbo[onsetT]

        # Rule 02
        NspTL = np.where(spAT < 0)[0]
        NspT = spT[NspTL]
        if len(NspT) >= 1:
            CNonsetT = onsetT[NspTL - 1]
            spT = np.setdiff1d(spT, NspT)
            onsetT = np.setdiff1d(onsetT, CNonsetT)
            spAT = xbo[spT]
            onsetAT = xbo[onsetT]

        # Rule 03
        exsp = 0
        RspT = []
        for i in range(2, len(spT)):
            if spAT[i] < RTHB * spAT[i - 1]:
                RspT.append(i)
                spT[i] = spT[i - 1]
                spAT[i] = xbo[spT[i]]
                exsp += 1

        spT = np.unique(spT)
        spAT = xbo[spT]
        if exsp >= 1:
            RonsetT = onsetT[np.array(RspT) - 1]
            onsetT = np.setdiff1d(onsetT, RonsetT)
            onsetAT = xbo[onsetT]

    else:
        # Rule 01
        PonsetTL = np.where(onsetAT > 0)[0]
        PonsetT = onsetT[PonsetTL]
        check = 0

        if len(PonsetT) >= 1:
            if len(PonsetT) == 1:
                if PonsetT[-1] == onsetT[-1]:
                    check = 1
                else:
                    CPspT = spT[PonsetTL]
            else:
                if PonsetT[-1] == onsetT[-1] and PonsetT[-1] > spT[-1]:
                    CPspT = np.array([spT[PonsetTL[i]] for i in range(len(PonsetT)-1)])
                else:
                    CPspT = spT[PonsetTL]

            if check == 0:
                spT = np.setdiff1d(spT, CPspT)
                onsetT = np.setdiff1d(onsetT, PonsetT)
                spAT = xbo[spT]
                onsetAT = xbo[onsetT]

        # Rule 02
        NspTL = np.where(spAT < 0)[0]
        NspT = spT[NspTL]
        if len(NspT) >= 1:
            CNonsetT = onsetT[NspTL]
            spT = np.setdiff1d(spT, NspT)
            onsetT = np.setdiff1d(onsetT, CNonsetT)
            spAT = xbo[spT]
            onsetAT = xbo[onsetT]

        # Rule 03
        exsp = 0
        RspT = []
        for i in range(1, len(spT)):
            if spAT[i] < RTHB * spAT[i - 1]:
                RspT.append(i)
                spT[i] = spT[i - 1]
                spAT[i] = xbo[spT[i]]
                exsp += 1

        spT = np.unique(spT)
        spAT = xbo[spT]
        if exsp >= 1:
            RonsetT = onsetT[np.array(RspT)]
            onsetT = np.setdiff1d(onsetT, RonsetT)
            onsetAT = xbo[onsetT]

    return spT, spAT, onsetT, onsetAT